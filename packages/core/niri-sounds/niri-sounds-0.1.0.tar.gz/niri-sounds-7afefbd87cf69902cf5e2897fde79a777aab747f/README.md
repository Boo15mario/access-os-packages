# niri-sounds
A simple python script for sound events in Niri
## Installation
Copy niri_sound.py somewhere or use this repository. Add the following line to your config.kdl near all the spawn-at-startup entries:
``` kdl
spawn-at-startup "/path/to/niri_sound.py"
```
## Dependencies
Just sox and a working Python installation. This is a port of the [i38](https://git.stormux.org/storm/i38) sound script to work with Niri. Some sounds are removed purely because Niri doesn't expose those events on the socket, and the move sound was also removed because Niri fires it on every window open or close.
