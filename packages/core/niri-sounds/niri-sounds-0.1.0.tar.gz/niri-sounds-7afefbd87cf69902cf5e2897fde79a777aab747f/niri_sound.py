#!/usr/bin/env python3

# This file is part of I38.

# I38 is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation,
# either version 3 of the License, or (at your option) any later version.

# I38 is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
# PURPOSE. See the GNU General Public License for more details.

# You should have received a copy of the GNU General Public License along with I38. If not, see <https://www.gnu.org/licenses/>.

"""
Sound feedback for Niri compositor.

This script connects to Niri's IPC socket and plays sounds for various events.
Equivalent to sound.py for i3, adapted for Niri's event model.

Supported events:
- WindowOpenedOrChanged: New window sound
- WindowClosed: Window close sound
- WorkspaceActivated: Spatial audio + speech announcement (like announce_workspace.sh)
- WindowLayoutsChanged: Window move sound
- OverviewOpenedOrClosed: Overview toggle sound

Not available in Niri IPC:
- Mode changes (Niri doesn't have modes like i3's ratpoison/bypass)
- Fullscreen toggle (no explicit event exposed)
- Shutdown/restart events (not exposed via IPC)
"""

import json
import os
import socket
import subprocess
import sys

# Track state to avoid playing sounds for initial state on startup
known_window_ids = set()
initial_sync_complete = False
last_overview_state = None
# Track workspaces for spatial audio and announcements
workspace_info = {}  # id -> {idx, name, is_active}
last_active_workspace_id = None


def play_sound_async(command):
    """Play a sound asynchronously without blocking the event loop"""
    try:
        subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True
        )
    except Exception:
        # Silently ignore sound playback errors
        pass


def on_window_opened(window):
    """Handle window opened or changed event"""
    try:
        app_id = window.get('app_id', '')
        title = window.get('title', '')
        # Skip notification daemon sounds (it has its own sound)
        if app_id == 'xfce4-notifyd' or title == 'xfce4-notifyd':
            play_sound_async('play -nqV0 synth .05 sq 1800 tri 2400 delay 0 .03 remix - repeat 2 echo .55 0.7 20 1 norm -12')
        else:
            play_sound_async('play -nqV0 synth .25 sin 440:880 sin 480:920 remix - norm -3 pitch -500')
    except Exception:
        pass


def on_window_closed(window_id):
    """Handle window closed event"""
    try:
        # We don't have window info at close time, so play generic close sound
        # (Can't check for notification daemon like in i3)
        play_sound_async('play -nqV0 synth .25 sin 880:440 sin 920:480 remix - norm -3 pitch -500')
    except Exception:
        pass


def on_workspace_activated(workspace_id, focused):
    """Handle workspace activation event with spatial audio"""
    global last_active_workspace_id

    # Only play sound if this is actually a workspace switch (not just focus change)
    if workspace_id == last_active_workspace_id:
        return

    last_active_workspace_id = workspace_id

    try:
        # Get workspace info for spatial positioning
        ws = workspace_info.get(workspace_id, {})
        idx = ws.get('idx', 1)

        # Get total workspace count for dynamic panning
        total_workspaces = len(workspace_info)
        if total_workspaces <= 1:
            # Single workspace - center pan
            left = 0.5
            right = 0.5
        else:
            # Calculate position as 0.0 (leftmost) to 1.0 (rightmost)
            # idx is 1-based, so subtract 1 for 0-based position
            position = (idx - 1) / (total_workspaces - 1)

            # Map position to stereo pan
            # Left channel: 0.9 at position 0, 0.0 at position 1
            # Right channel: 0.0 at position 0, 0.9 at position 1
            left = 0.9 * (1.0 - position)
            right = 0.9 * position

        # Play spatial sound with panning (Niri announces to Orca directly)
        play_sound_async(
            f'play -nqV0 synth pi fade 0 .25 .15 pad 0 1 reverb overdrive riaa norm -8 speed 1 remix v0.{int(left*10)} v0.{int(right*10)}'
        )
    except Exception:
        pass


def on_overview_toggled(is_open):
    """Handle overview opened/closed event"""
    try:
        if is_open:
            # Opening overview - ascending arpeggio like entering panel mode in i3
            play_sound_async('play -nqV0 synth 0.05 pluck F3 norm -8 : synth 0.05 pluck C4 norm -8 : synth 0.05 pluck F4 norm -8 : synth 0.05 pluck C5 norm -8')
        else:
            # Closing overview - descending arpeggio like exiting panel mode in i3
            play_sound_async('play -nqV0 synth 0.05 pluck C5 norm -8 : synth 0.05 pluck F4 norm -8 : synth 0.05 pluck C4 norm -8 : synth 0.05 pluck F3 norm -8')
    except Exception:
        pass


def handle_event(event):
    """Dispatch event to appropriate handler"""
    global known_window_ids, initial_sync_complete, last_overview_state
    global workspace_info, last_active_workspace_id

    # Events are JSON objects with a single key indicating the event type
    # and a value containing the event data

    # WorkspacesChanged provides workspace list - track for spatial audio
    if 'WorkspacesChanged' in event:
        workspaces = event['WorkspacesChanged'].get('workspaces', [])
        workspace_info.clear()
        for ws in workspaces:
            ws_id = ws.get('id')
            if ws_id is not None:
                workspace_info[ws_id] = {
                    'idx': ws.get('idx', 1),
                    'name': ws.get('name'),
                    'is_active': ws.get('is_active', False)
                }
                # Track initial active workspace
                if ws.get('is_active') and last_active_workspace_id is None:
                    last_active_workspace_id = ws_id
        return

    # WindowsChanged is the initial bulk window list - use it to track known windows
    if 'WindowsChanged' in event:
        windows = event['WindowsChanged'].get('windows', [])
        for w in windows:
            if 'id' in w:
                known_window_ids.add(w['id'])
        return

    # ConfigLoaded marks the end of initial state sync
    if 'ConfigLoaded' in event:
        initial_sync_complete = True
        return

    # Skip most events until initial sync is complete
    if not initial_sync_complete:
        # Track initial overview state but don't play sound
        if 'OverviewOpenedOrClosed' in event:
            last_overview_state = event['OverviewOpenedOrClosed'].get('is_open', False)
        return

    if 'WindowOpenedOrChanged' in event:
        window = event['WindowOpenedOrChanged'].get('window', {})
        window_id = window.get('id')
        # Only play sound for genuinely new windows, not updates to existing ones
        if window_id and window_id not in known_window_ids:
            known_window_ids.add(window_id)
            on_window_opened(window)

    elif 'WindowClosed' in event:
        window_id = event['WindowClosed'].get('id')
        if window_id:
            known_window_ids.discard(window_id)
        on_window_closed(window_id)

    elif 'WorkspaceActivated' in event:
        data = event['WorkspaceActivated']
        on_workspace_activated(data.get('id'), data.get('focused', False))

    # WindowLayoutsChanged removed - it fires alongside open/close events in Niri,
    # causing double sounds. Unlike i3's window::move, Niri's layout changes are
    # too frequent and overlap with other events.

    elif 'OverviewOpenedOrClosed' in event:
        is_open = event['OverviewOpenedOrClosed'].get('is_open', False)
        # Only play sound if state actually changed
        if last_overview_state is not None and is_open != last_overview_state:
            on_overview_toggled(is_open)
        last_overview_state = is_open


def connect_to_niri():
    """Connect to Niri's IPC socket"""
    socket_path = os.environ.get('NIRI_SOCKET')
    if not socket_path:
        print("Error: NIRI_SOCKET environment variable not set.", file=sys.stderr)
        print("Make sure you're running this from within a Niri session.", file=sys.stderr)
        sys.exit(1)

    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        sock.connect(socket_path)
    except (socket.error, OSError) as e:
        print(f"Error connecting to Niri socket at {socket_path}: {e}", file=sys.stderr)
        sys.exit(1)

    return sock


def request_event_stream(sock):
    """Send EventStream request to start receiving events"""
    request = json.dumps("EventStream") + "\n"
    sock.sendall(request.encode('utf-8'))


def main():
    """Main event loop"""
    sock = connect_to_niri()
    request_event_stream(sock)

    # Buffer for reading lines
    buffer = ""
    # Track if we've seen the initial acknowledgment
    got_ack = False

    try:
        while True:
            # Read data from socket
            data = sock.recv(4096)
            if not data:
                print("Connection to Niri closed.", file=sys.stderr)
                break

            buffer += data.decode('utf-8')

            # Process complete lines (events are one JSON object per line)
            while '\n' in buffer:
                line, buffer = buffer.split('\n', 1)
                line = line.strip()
                if not line:
                    continue

                try:
                    event = json.loads(line)
                    # First response is {"Ok":"Handled"} acknowledgment - skip it
                    if not got_ack:
                        if isinstance(event, dict) and event.get('Ok') == 'Handled':
                            got_ack = True
                            continue
                    # Subsequent events come directly as {"EventType": {...}}
                    if isinstance(event, dict):
                        handle_event(event)
                except json.JSONDecodeError:
                    # Skip malformed JSON
                    pass

    except KeyboardInterrupt:
        pass
    finally:
        sock.close()


if __name__ == '__main__':
    main()
