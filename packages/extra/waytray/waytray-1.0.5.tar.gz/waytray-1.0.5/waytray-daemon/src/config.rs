use anyhow::{Context, Result};
use serde::Deserialize;
use std::fs;
use std::path::PathBuf;

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct Config {
    pub modules: ModulesConfig,
    pub notifications: NotificationsConfig,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            modules: ModulesConfig::default(),
            notifications: NotificationsConfig::default(),
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct ModulesConfig {
    /// Module ordering - modules appear in this order in the panel
    /// Modules not listed here appear after listed ones
    #[serde(default)]
    pub order: Vec<String>,
    pub tray: TrayModuleConfig,
    pub battery: Option<BatteryModuleConfig>,
    pub clock: Option<ClockModuleConfig>,
    pub system: Option<SystemModuleConfig>,
    pub network: Option<NetworkModuleConfig>,
    pub weather: Option<WeatherModuleConfig>,
    pub pipewire: Option<PipewireModuleConfig>,
    pub privacy: Option<PrivacyModuleConfig>,
    pub power_profiles: Option<PowerProfilesModuleConfig>,
    pub gpu: Option<GpuModuleConfig>,
    #[serde(default)]
    pub scripts: Vec<ScriptModuleConfig>,
}

impl Default for ModulesConfig {
    fn default() -> Self {
        Self {
            order: vec!["tray".to_string()],
            tray: TrayModuleConfig::default(),
            battery: None,
            clock: None,
            system: None,
            network: None,
            weather: None,
            pipewire: None,
            privacy: None,
            power_profiles: None,
            gpu: None,
            scripts: Vec::new(),
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct TrayModuleConfig {
    pub enabled: bool,
}

impl Default for TrayModuleConfig {
    fn default() -> Self {
        Self { enabled: true }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct BatteryModuleConfig {
    pub enabled: bool,
    /// Battery percentage threshold for low battery notification
    pub low_threshold: u8,
    /// Battery percentage threshold for critical battery notification
    pub critical_threshold: u8,
    /// Whether to notify when battery is fully charged
    pub notify_full_charge: bool,
    /// Sound file path to play on low battery (optional)
    pub low_sound: Option<String>,
    /// Sound file path to play on critical battery (optional)
    pub critical_sound: Option<String>,
    /// Sound file path to play when fully charged (optional)
    pub full_sound: Option<String>,
}

impl Default for BatteryModuleConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            low_threshold: 20,
            critical_threshold: 10,
            notify_full_charge: false,
            low_sound: None,
            critical_sound: None,
            full_sound: None,
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct ClockModuleConfig {
    pub enabled: bool,
    /// Time format string (strftime format)
    /// Default: "%H:%M" (24-hour time)
    /// Examples: "%I:%M %p" (12-hour with AM/PM), "%H:%M:%S" (with seconds)
    pub format: String,
    /// Date format for tooltip (strftime format)
    /// Default: "%A, %B %d, %Y" (e.g., "Monday, January 15, 2024")
    pub date_format: String,
}

impl Default for ClockModuleConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            format: "%H:%M".to_string(),
            date_format: "%A, %B %d, %Y".to_string(),
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct SystemModuleConfig {
    pub enabled: bool,
    pub show_cpu: bool,
    pub show_memory: bool,
    pub show_temperature: bool,
    /// Show the process using the most CPU in the CPU tooltip
    pub show_top_cpu_process: bool,
    /// Show the process using the most memory in the memory tooltip
    pub show_top_memory_process: bool,
    /// Update interval in seconds
    pub interval_seconds: u64,
}

impl Default for SystemModuleConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            show_cpu: true,
            show_memory: true,
            show_temperature: false,
            show_top_cpu_process: false,
            show_top_memory_process: false,
            interval_seconds: 5,
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct NetworkModuleConfig {
    pub enabled: bool,
    /// Network interface to monitor (empty = auto-detect default route interface)
    pub interface: String,
    /// Show IP address
    pub show_ip: bool,
    /// Show upload/download speed
    pub show_speed: bool,
    /// Update interval in seconds
    pub interval_seconds: u64,
}

impl Default for NetworkModuleConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            interface: String::new(), // Auto-detect
            show_ip: false,
            show_speed: true,
            interval_seconds: 2,
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct WeatherModuleConfig {
    pub enabled: bool,
    /// Location for weather (city name, e.g. "London" or "New York")
    /// Leave empty to auto-detect from IP
    pub location: String,
    /// Update interval in seconds
    pub interval_seconds: u64,
    /// Temperature unit: "celsius" or "fahrenheit"
    pub units: String,
}

impl Default for WeatherModuleConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            location: String::new(), // Empty = auto-detect
            interval_seconds: 1800,  // 30 minutes
            units: "celsius".to_string(),
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct PipewireModuleConfig {
    pub enabled: bool,
    /// Show volume percentage in label
    pub show_volume: bool,
    /// Maximum volume percentage (100 = normal, 150 = allow boost)
    pub max_volume: u32,
    /// Volume step for scroll adjustment (percentage)
    pub scroll_step: u32,
    /// Show microphone control item
    pub show_microphone: bool,
    /// Show microphone volume percentage in label
    pub show_mic_volume: bool,
    /// Maximum microphone volume percentage (100 = normal, 150 = allow boost)
    pub mic_max_volume: u32,
    /// Microphone volume step for scroll adjustment (percentage)
    pub mic_scroll_step: u32,
}

impl Default for PipewireModuleConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            show_volume: true,
            max_volume: 100,
            scroll_step: 5,
            show_microphone: true,
            show_mic_volume: true,
            mic_max_volume: 100,
            mic_scroll_step: 5,
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct PrivacyModuleConfig {
    pub enabled: bool,
    /// Update interval in seconds
    pub interval_seconds: u64,
    /// Show an idle item when no apps are using the microphone
    pub show_when_idle: bool,
}

impl Default for PrivacyModuleConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            interval_seconds: 2,
            show_when_idle: false,
        }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct PowerProfilesModuleConfig {
    pub enabled: bool,
}

impl Default for PowerProfilesModuleConfig {
    fn default() -> Self {
        Self { enabled: true }
    }
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct GpuModuleConfig {
    pub enabled: bool,
    /// Show GPU temperature
    pub show_temperature: bool,
    /// Show the process using the most GPU memory
    pub show_top_process: bool,
    /// Update interval in seconds
    pub interval_seconds: u64,
}

impl Default for GpuModuleConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            show_temperature: false,
            show_top_process: false,
            interval_seconds: 5,
        }
    }
}

/// Script execution mode
#[derive(Debug, Clone, Copy, Deserialize, Default, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum ScriptMode {
    /// Run script once when module loads
    Once,
    /// Spawn as long-running process, monitor stdout for updates
    Watch,
    /// Run script at regular intervals
    #[default]
    Interval,
    /// Run script when client connects/requests refresh
    OnConnect,
}

fn default_script_interval() -> u64 {
    30
}

#[derive(Debug, Clone, Deserialize)]
pub struct ScriptModuleConfig {
    /// Unique identifier for this script (used in module name)
    pub id: String,
    /// Path to the script to execute
    pub path: String,
    /// Must be explicitly set to true to enable (security measure)
    #[serde(default)]
    pub enabled: bool,
    /// Execution mode: once, watch, interval, or on_connect
    #[serde(default)]
    pub mode: ScriptMode,
    /// Update interval in seconds (only used for interval mode)
    #[serde(default = "default_script_interval")]
    pub interval_seconds: u64,
    /// Default icon name from theme (can be overridden by script output)
    pub icon: Option<String>,
}

#[derive(Debug, Clone, Deserialize)]
#[serde(default)]
pub struct NotificationsConfig {
    pub enabled: bool,
    /// Notification timeout in milliseconds (0 = no timeout)
    pub timeout_ms: u32,
}

impl Default for NotificationsConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            timeout_ms: 5000,
        }
    }
}

impl Config {
    /// Load configuration from the default path (~/.config/waytray/config.toml)
    /// Creates the config file with defaults if it doesn't exist
    pub fn load() -> Result<Self> {
        let path = Self::config_path();
        Self::load_from_path(&path)
    }

    /// Load configuration from a specific path
    /// Creates the config file with defaults if it doesn't exist
    pub fn load_from_path(path: &PathBuf) -> Result<Self> {
        if !path.exists() {
            tracing::info!("Config file not found at {:?}, creating with defaults", path);
            Self::write_default_config(path)?;
            return Ok(Self::default());
        }

        let content = fs::read_to_string(path)
            .with_context(|| format!("Failed to read config file: {:?}", path))?;

        let config: Config = toml::from_str(&content)
            .with_context(|| format!("Failed to parse config file: {:?}", path))?;

        // Validate battery thresholds
        if let Some(ref battery) = config.modules.battery {
            if battery.low_threshold <= battery.critical_threshold {
                tracing::warn!(
                    "Battery config: low_threshold ({}) should be greater than critical_threshold ({}). \
                     Critical notifications may not trigger correctly.",
                    battery.low_threshold,
                    battery.critical_threshold
                );
            }
        }

        tracing::info!("Loaded config from {:?}", path);
        Ok(config)
    }

    /// Write the default configuration to a file
    fn write_default_config(path: &PathBuf) -> Result<()> {
        // Create parent directory if needed
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)
                .with_context(|| format!("Failed to create config directory: {:?}", parent))?;
        }

        let default_config = Self::default_config_string();
        fs::write(path, default_config)
            .with_context(|| format!("Failed to write default config to {:?}", path))?;

        tracing::info!("Created default config at {:?}", path);
        Ok(())
    }

    /// Generate the default configuration as a TOML string
    fn default_config_string() -> String {
        r#"# WayTray Configuration
# See https://github.com/destructatron/waytray for documentation

[modules]
# Module display order (left to right)
# Modules not listed appear after these
order = ["tray"]

[modules.tray]
enabled = true

# Uncomment to enable battery module
# [modules.battery]
# enabled = true
# low_threshold = 20
# critical_threshold = 10
# notify_full_charge = false
# low_sound = "~/.config/waytray/sounds/low.wav"
# critical_sound = "~/.config/waytray/sounds/critical.wav"
# full_sound = "~/.config/waytray/sounds/full.wav"

# Uncomment to enable clock module
# [modules.clock]
# enabled = true
# format = "%H:%M"
# date_format = "%A, %B %d, %Y"

# Uncomment to enable system (CPU/memory/temperature) module
# [modules.system]
# enabled = true
# show_cpu = true
# show_memory = true
# show_temperature = false
# show_top_cpu_process = false    # Show top CPU process in tooltip
# show_top_memory_process = false # Show top memory process in tooltip
# interval_seconds = 5

# Uncomment to enable weather module (uses wttr.in, no API key needed)
# [modules.weather]
# enabled = true
# location = ""           # Empty = auto-detect from IP
# units = "celsius"       # or "fahrenheit"
# interval_seconds = 1800 # 30 minutes

# Uncomment to enable network module
# [modules.network]
# enabled = true
# interface = ""          # Empty = auto-detect default route interface
# show_ip = false
# show_speed = true
# interval_seconds = 2

# Uncomment to enable pipewire/pulseaudio volume module
# [modules.pipewire]
# enabled = true
# show_volume = true      # Show volume percentage in label
# max_volume = 100        # Maximum volume (100 = normal, 150 = allow boost)
# scroll_step = 5         # Volume change per scroll step
# show_microphone = true  # Show microphone control item
# show_mic_volume = true  # Show mic volume percentage in label
# mic_max_volume = 100    # Maximum mic volume (100 = normal, 150 = allow boost)
# mic_scroll_step = 5     # Mic volume change per scroll step

# Uncomment to enable privacy module (microphone usage)
# [modules.privacy]
# enabled = true
# interval_seconds = 2    # Polling interval in seconds
# show_when_idle = false  # Show an idle item when no apps are using the mic

# Uncomment to enable power profiles module (requires power-profiles-daemon)
# [modules.power_profiles]
# enabled = true

# Uncomment to enable GPU module (supports NVIDIA via nvidia-smi, AMD via sysfs)
# [modules.gpu]
# enabled = true
# show_temperature = false    # Show GPU temperature
# show_top_process = false    # Show top GPU memory process in tooltip (NVIDIA only)
# interval_seconds = 5

# Custom scripts module - each script must be explicitly enabled for security
# Script output format:
#   - Line-based: first line = label, second line = tooltip (optional)
#   - JSON: {"label": "text", "tooltip": "...", "icon": "...", "actions": [...]}
# Modes:
#   - once: Run script once when module loads
#   - watch: Spawn script as long-running process, monitor stdout for updates
#   - interval: Run script at regular intervals
#   - on_connect: Run script when client connects
#
# [[modules.scripts]]
# id = "my-script"
# path = "/path/to/script.sh"
# enabled = true              # REQUIRED: must be true to run (security)
# mode = "interval"           # once, watch, interval, on_connect
# interval_seconds = 30       # Only used for interval mode
# icon = "utilities-terminal" # Default icon (can be overridden by script)

[notifications]
enabled = true
timeout_ms = 5000
"#.to_string()
    }

    /// Get the default config file path
    pub fn config_path() -> PathBuf {
        dirs::config_dir()
            .unwrap_or_else(|| PathBuf::from("."))
            .join("waytray")
            .join("config.toml")
    }

    /// Get the list of module names in order
    pub fn module_order(&self) -> Vec<String> {
        let mut order = self.modules.order.clone();

        // Add any enabled modules not in the order list
        if self.modules.tray.enabled && !order.contains(&"tray".to_string()) {
            order.push("tray".to_string());
        }
        if let Some(ref battery) = self.modules.battery {
            if battery.enabled && !order.contains(&"battery".to_string()) {
                order.push("battery".to_string());
            }
        }
        if let Some(ref clock) = self.modules.clock {
            if clock.enabled && !order.contains(&"clock".to_string()) {
                order.push("clock".to_string());
            }
        }
        if let Some(ref system) = self.modules.system {
            if system.enabled && !order.contains(&"system".to_string()) {
                order.push("system".to_string());
            }
        }
        if let Some(ref weather) = self.modules.weather {
            if weather.enabled && !order.contains(&"weather".to_string()) {
                order.push("weather".to_string());
            }
        }
        if let Some(ref network) = self.modules.network {
            if network.enabled && !order.contains(&"network".to_string()) {
                order.push("network".to_string());
            }
        }
        if let Some(ref pipewire) = self.modules.pipewire {
            if pipewire.enabled && !order.contains(&"pipewire".to_string()) {
                order.push("pipewire".to_string());
            }
        }
        if let Some(ref privacy) = self.modules.privacy {
            if privacy.enabled && !order.contains(&"privacy".to_string()) {
                order.push("privacy".to_string());
            }
        }
        if let Some(ref power_profiles) = self.modules.power_profiles {
            if power_profiles.enabled && !order.contains(&"power_profiles".to_string()) {
                order.push("power_profiles".to_string());
            }
        }
        if let Some(ref gpu) = self.modules.gpu {
            if gpu.enabled && !order.contains(&"gpu".to_string()) {
                order.push("gpu".to_string());
            }
        }
        // Add scripts module if there are any enabled scripts
        let has_enabled_scripts = self.modules.scripts.iter().any(|s| s.enabled);
        if has_enabled_scripts && !order.contains(&"scripts".to_string()) {
            order.push("scripts".to_string());
        }

        order
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_default_config() {
        let config = Config::default();
        assert!(config.modules.tray.enabled);
        assert!(config.modules.battery.is_none());
        assert!(config.notifications.enabled);
    }

    #[test]
    fn test_parse_minimal_config() {
        let toml = r#"
[modules.tray]
enabled = true
"#;
        let config: Config = toml::from_str(toml).unwrap();
        assert!(config.modules.tray.enabled);
    }

    #[test]
    fn test_parse_full_config() {
        let toml = r#"
[modules]
order = ["tray", "battery", "system"]

[modules.tray]
enabled = true

[modules.battery]
enabled = true
low_threshold = 15
critical_threshold = 5

[modules.system]
enabled = true
show_cpu = true
show_memory = true
interval_seconds = 10

[[modules.scripts]]
id = "my-script"
path = "/path/to/script.sh"
enabled = true
mode = "interval"
interval_seconds = 30
icon = "utilities-terminal"

[notifications]
enabled = true
timeout_ms = 3000
"#;
        let config: Config = toml::from_str(toml).unwrap();
        assert!(config.modules.tray.enabled);
        assert!(config.modules.battery.as_ref().unwrap().enabled);
        assert_eq!(config.modules.battery.as_ref().unwrap().low_threshold, 15);
        assert!(config.modules.system.as_ref().unwrap().show_cpu);
        assert_eq!(config.modules.scripts.len(), 1);
        assert_eq!(config.modules.scripts[0].id, "my-script");
        assert!(config.modules.scripts[0].enabled);
        assert_eq!(config.modules.scripts[0].mode, ScriptMode::Interval);
        assert_eq!(config.notifications.timeout_ms, 3000);
    }

    #[test]
    fn test_module_order() {
        let toml = r#"
[modules]
order = ["battery", "tray"]

[modules.tray]
enabled = true

[modules.battery]
enabled = true
"#;
        let config: Config = toml::from_str(toml).unwrap();
        let order = config.module_order();
        assert_eq!(order[0], "battery");
        assert_eq!(order[1], "tray");
    }
}
